# -*- coding: utf-8 -*-

from . import partner
from . import college_department
from . import college_program
from . import college_module
from . import college_marks
from . import college_student
from . import college_staff
from . import college_staff_academic
from . import college_staff_admin
from . import college_enrolled_student
